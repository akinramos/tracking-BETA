<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 15">
<meta name=Originator content="Microsoft Word 15">
<link rel=File-List href="obr1_files/filelist.xml">
<link rel=Edit-Time-Data href="obr1_files/editdata.mso">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>Jassie Anne C. Tan</o:Author>
  <o:Template>Normal</o:Template>
  <o:LastAuthor>RICTMU</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>115</o:TotalTime>
  <o:LastPrinted>2021-04-21T06:34:00Z</o:LastPrinted>
  <o:Created>2021-07-06T02:38:00Z</o:Created>
  <o:LastSaved>2021-07-06T02:38:00Z</o:LastSaved>
  <o:Pages>2</o:Pages>
  <o:Words>274</o:Words>
  <o:Characters>1566</o:Characters>
  <o:Lines>13</o:Lines>
  <o:Paragraphs>3</o:Paragraphs>
  <o:CharactersWithSpaces>1837</o:CharactersWithSpaces>
  <o:Version>16.00</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:RelyOnVML/>
  <o:AllowPNG/>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<link rel=dataStoreItem href="obr1_files/item0007.xml"
target="obr1_files/props008.xml">
<link rel=themeData href="obr1_files/themedata.thmx">
<link rel=colorSchemeMapping href="obr1_files/colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:View>Print</w:View>
  <w:Zoom>110</w:Zoom>
  <w:SpellingState>Clean</w:SpellingState>
  <w:GrammarState>Clean</w:GrammarState>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>EN-PH</w:LidThemeOther>
  <w:LidThemeAsian>JA</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:UseWord2010TableStyleRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:EnableOpenTypeKerning/>
   <w:DontFlipMirrorIndents/>
   <w:OverrideTableStyleHps/>
  </w:Compatibility>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="&#45;-"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="false"
  DefSemiHidden="false" DefQFormat="false" DefPriority="99"
  LatentStyleCount="371">
  <w:LsdException Locked="false" Priority="0" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 9"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 9"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footnote text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="header"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footer"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index heading"/>
  <w:LsdException Locked="false" Priority="35" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="table of figures"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="envelope address"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="envelope return"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footnote reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="line number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="page number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="endnote reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="endnote text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="table of authorities"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="macro"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="toa heading"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 5"/>
  <w:LsdException Locked="false" Priority="10" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Closing"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Signature"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="true"
   UnhideWhenUsed="true" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Message Header"/>
  <w:LsdException Locked="false" Priority="11" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Salutation"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Date"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text First Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text First Indent 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Note Heading"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Block Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Hyperlink"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="FollowedHyperlink"/>
  <w:LsdException Locked="false" Priority="22" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Document Map"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Plain Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="E-mail Signature"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Top of Form"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Bottom of Form"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal (Web)"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Acronym"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Address"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Cite"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Code"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Definition"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Keyboard"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Preformatted"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Sample"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Typewriter"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Variable"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal Table"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation subject"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="No List"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Contemporary"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Elegant"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Professional"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Subtle 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Subtle 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Balloon Text"/>
  <w:LsdException Locked="false" Priority="39" Name="Table Grid"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Theme"/>
  <w:LsdException Locked="false" SemiHidden="true" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" SemiHidden="true" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" QFormat="true"
   Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" QFormat="true"
   Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" QFormat="true"
   Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" QFormat="true"
   Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" QFormat="true"
   Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" QFormat="true"
   Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" SemiHidden="true"
   UnhideWhenUsed="true" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="TOC Heading"/>
  <w:LsdException Locked="false" Priority="41" Name="Plain Table 1"/>
  <w:LsdException Locked="false" Priority="42" Name="Plain Table 2"/>
  <w:LsdException Locked="false" Priority="43" Name="Plain Table 3"/>
  <w:LsdException Locked="false" Priority="44" Name="Plain Table 4"/>
  <w:LsdException Locked="false" Priority="45" Name="Plain Table 5"/>
  <w:LsdException Locked="false" Priority="40" Name="Grid Table Light"/>
  <w:LsdException Locked="false" Priority="46" Name="Grid Table 1 Light"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark"/>
  <w:LsdException Locked="false" Priority="51" Name="Grid Table 6 Colorful"/>
  <w:LsdException Locked="false" Priority="52" Name="Grid Table 7 Colorful"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 1"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 1"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 1"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 2"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 2"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 2"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 3"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 3"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 3"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 4"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 4"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 4"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 5"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 5"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 5"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 6"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 6"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 6"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="46" Name="List Table 1 Light"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark"/>
  <w:LsdException Locked="false" Priority="51" Name="List Table 6 Colorful"/>
  <w:LsdException Locked="false" Priority="52" Name="List Table 7 Colorful"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 1"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 1"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 1"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 2"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 2"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 2"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 3"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 3"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 3"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 4"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 4"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 4"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 5"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 5"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 5"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 6"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 6"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 6"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 6"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:-536869121 1107305727 33554432 0 415 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-536858881 -1073732485 9 0 511 0;}
@font-face
	{font-family:"Segoe UI";
	panose-1:2 11 5 2 4 2 4 2 2 3;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-469750017 -1073683329 9 0 511 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:107%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Balloon Text Char";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:9.0pt;
	font-family:"Segoe UI",sans-serif;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-fareast-language:EN-US;}
span.BalloonTextChar
	{mso-style-name:"Balloon Text Char";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Balloon Text";
	mso-ansi-font-size:9.0pt;
	mso-bidi-font-size:9.0pt;
	font-family:"Segoe UI",sans-serif;
	mso-ascii-font-family:"Segoe UI";
	mso-hansi-font-family:"Segoe UI";
	mso-bidi-font-family:"Segoe UI";}
span.SpellE
	{mso-style-name:"";
	mso-spl-e:yes;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
.MsoPapDefault
	{mso-style-type:export-only;
	margin-bottom:8.0pt;
	line-height:107%;}
@page WordSection1
	{size:612.35pt 936.1pt;
	margin:36.0pt 36.0pt 36.0pt 36.0pt;
	mso-header-margin:35.45pt;
	mso-footer-margin:35.45pt;
	mso-vertical-page-align:middle;
	mso-paper-source:0;}
div.WordSection1
	{page:WordSection1;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin-top:0cm;
	mso-para-margin-right:0cm;
	mso-para-margin-bottom:8.0pt;
	mso-para-margin-left:0cm;
	line-height:107%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1027"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-PH style='tab-interval:36.0pt'>

<div class=WordSection1>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 align=left
 width=726 style='width:544.75pt;border-collapse:collapse;mso-yfti-tbllook:
 1184;mso-table-lspace:9.0pt;margin-left:6.75pt;mso-table-rspace:9.0pt;
 margin-right:6.75pt;mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:
 margin;mso-table-left:left;mso-table-top:-811.55pt;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:20.5pt'>
  <td width=48 nowrap valign=bottom style='width:36.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'><a name="RANGE!A1:M46"></a></td>
  <td width=34 nowrap valign=bottom style='width:25.75pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=40 nowrap valign=bottom style='width:29.9pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=48 nowrap valign=bottom style='width:36.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=45 nowrap valign=bottom style='width:33.4pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=53 nowrap valign=bottom style='width:40.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=18 nowrap valign=bottom style='width:13.35pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=96 nowrap valign=bottom style='width:72.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=45 nowrap valign=bottom style='width:33.85pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=57 nowrap valign=bottom style='width:42.6pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=72 nowrap valign=bottom style='width:54.15pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'></td>
  <td width=169 nowrap colspan=2 style='width:126.85pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:20.5pt'>
  <p class=MsoNormal align=right style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:right;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><i><span style='font-size:16.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Appendix
  11<o:p></o:p></span></i></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:20.5pt;border:none' width=0 height=27></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:1;height:4.25pt'>
  <td width=48 nowrap valign=bottom style='width:36.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=34 nowrap valign=bottom style='width:25.75pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=40 nowrap valign=bottom style='width:29.9pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=48 nowrap valign=bottom style='width:36.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=45 nowrap valign=bottom style='width:33.4pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=53 nowrap valign=bottom style='width:40.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=18 nowrap valign=bottom style='width:13.35pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=96 nowrap valign=bottom style='width:72.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=45 nowrap valign=bottom style='width:33.85pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=57 nowrap valign=bottom style='width:42.6pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=72 nowrap valign=bottom style='width:54.15pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'></td>
  <td width=169 nowrap colspan=2 valign=bottom style='width:126.85pt;
  border:none;border-bottom:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.25pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>&nbsp;<o:p></o:p></span></b></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:4.25pt;border:none' width=0 height=6></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:2;height:23.2pt'>
  <td width=485 colspan=10 style='width:363.7pt;border-top:solid windowtext 1.0pt;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:23.2pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><v:shapetype id="_x0000_t75" coordsize="21600,21600" o:spt="75"
   o:preferrelative="t" path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="Picture_x0020_1" o:spid="_x0000_s1026" type="#_x0000_t75"
   style='position:absolute;left:0;text-align:left;margin-left:-.1pt;
   margin-top:6.5pt;width:54.75pt;height:47.45pt;z-index:-251657216;
   visibility:visible;mso-wrap-style:square;mso-width-percent:0;
   mso-height-percent:0;mso-wrap-distance-left:9pt;mso-wrap-distance-top:0;
   mso-wrap-distance-right:9pt;mso-wrap-distance-bottom:0;
   mso-position-horizontal:absolute;mso-position-horizontal-relative:text;
   mso-position-vertical:absolute;mso-position-vertical-relative:text;
   mso-width-percent:0;mso-height-percent:0;mso-width-relative:page;
   mso-height-relative:page'>
   <v:imagedata src="obr1_files/image001.jpg" o:title="1208-dswd"/>
  </v:shape><b><span style='font-size:9.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'></span><o:p></o:p></span></b></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-size:14.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'></span>OBLIGATION REQUEST AND STATUS<o:p></o:p></span></b></p>
  </td>
  <td width=241 colspan=3 valign=bottom style='width:181.05pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:23.2pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Serial No. : ____________________<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:23.2pt;border:none' width=0 height=31></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:3;height:24.4pt'>
  <td width=485 colspan=10 valign=bottom style='width:363.7pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:24.4pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'></span></span><b
  style='mso-bidi-font-weight:normal'><span style='font-size:10.5pt;font-family:
  "Times New Roman",serif;mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  EN-PH'>DEPARTMENT OF SOCIAL WELFARE AND DEVELOPMENT<o:p></o:p></span></b></p>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-size:10.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'></span>Field Office XI<o:p></o:p></span></p>
  </td>
  <td width=241 colspan=3 style='width:181.05pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:24.4pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Date : ________________________<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:24.4pt;border:none' width=0 height=33></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:4;height:4.2pt'>
  <td width=485 colspan=10 valign=top style='width:363.7pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'><a name="RANGE!A1:M44"></a></td>
  <td width=241 colspan=3 valign=top style='width:181.05pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Fund Cluster : <o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:4.2pt;border:none' width=0 height=6></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:5;height:25.75pt'>
  <td width=122 colspan=3 style='width:91.8pt;border-top:solid windowtext 1.0pt;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-right-alt:solid black .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:
  25.75pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Payee<o:p></o:p></span></p>
  </td>
  <td width=604 colspan=10 style='width:452.95pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:25.75pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><b><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Mia Dulce Corazon S. Vergara et. al<o:p></o:p></span></b></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:25.75pt;border:none' width=0 height=34></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:6;height:21.1pt'>
  <td width=122 colspan=3 style='width:91.8pt;border-top:solid windowtext 1.0pt;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-right-alt:solid black .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:
  21.1pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Office<o:p></o:p></span></p>
  </td>
  <td width=604 colspan=10 style='width:452.95pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-right-alt:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:21.1pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>DSWD FO XI<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:21.1pt;border:none' width=0 height=28></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:7;height:24.45pt'>
  <td width=122 colspan=3 style='width:91.8pt;border-top:solid windowtext 1.0pt;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-right-alt:solid black .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:
  24.45pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Address<o:p></o:p></span></p>
  </td>
  <td width=604 colspan=10 style='width:452.95pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-right-alt:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:24.45pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>R. Magsaysay cor. <span class=SpellE>Suazo</span>
  St. Davao City<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:24.45pt;border:none' width=0 height=33></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:8;height:14.65pt'>
  <td width=122 colspan=3 rowspan=2 style='width:91.8pt;border-top:windowtext;
  border-left:windowtext;border-bottom:black;border-right:black;border-style:
  solid;border-width:1.0pt;mso-border-top-alt:windowtext 1.0pt;mso-border-left-alt:
  windowtext 1.0pt;mso-border-bottom-alt:black 1.0pt;mso-border-right-alt:black .5pt;
  mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;height:14.65pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Responsibility Center<o:p></o:p></span></p>
  </td>
  <td width=260 colspan=5 rowspan=2 style='width:195.15pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black 1.0pt;
  mso-border-right-alt:black .5pt;mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.65pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Particulars<o:p></o:p></span></p>
  </td>
  <td width=102 colspan=2 rowspan=2 style='width:76.7pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black 1.0pt;
  mso-border-right-alt:black .5pt;mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.65pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";color:black;mso-fareast-language:EN-PH'>MFO/PAP<o:p></o:p></span></p>
  </td>
  <td width=72 rowspan=2 style='width:53.9pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black 1.0pt;
  mso-border-right-alt:windowtext .5pt;mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.65pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";color:black;mso-fareast-language:EN-PH'>UACS Object Code<o:p></o:p></span></p>
  </td>
  <td width=169 colspan=2 rowspan=2 style='width:127.1pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.65pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Amount<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:14.65pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:9;height:14.65pt'>
  <![if !supportMisalignedRows]>
  <td style='height:14.65pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:10;height:13.25pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=260 nowrap colspan=5 rowspan=12 valign=top style='width:195.15pt;
  border:none;border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Reimbursement of Travel Expenses for the month of
  April 2021<o:p></o:p></span></p>
  </td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:11;height:13.25pt'>
  <td width=122 nowrap colspan=3 valign=top style='width:91.8pt;border-top:
  none;border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal align=right style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:right;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>&#8369; 44,100.00<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:12;height:19.35pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:19.35pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:19.35pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:19.35pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:19.35pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:19.35pt;border:none' width=0 height=26></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:13;height:13.25pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:14;height:13.25pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:15;height:13.25pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:16;height:13.25pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:17;height:13.25pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:18;height:13.25pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:19;height:16.5pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:16.5pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:16.5pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:16.5pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:16.5pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:16.5pt;border:none' width=0 height=22></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:20;height:16.5pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:16.5pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:16.5pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:16.5pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:16.5pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:16.5pt;border:none' width=0 height=22></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:21;height:4.2pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:4.2pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:4.2pt;border:none' width=0 height=6></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:22;height:15.7pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'></td>
  <td width=260 nowrap colspan=5 style='width:195.15pt;border:none;border-right:
  solid black 1.0pt;mso-border-right-alt:solid black .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.7pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Total<o:p></o:p></span></p>
  </td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'></td>
  <td width=72 nowrap valign=top style='width:53.9pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:15.7pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'>
  <p class=MsoNormal align=right style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:right;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>&#8369;44,100.00</span></b><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'><o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:15.7pt;border:none' width=0 height=21></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:23;height:4.2pt'>
  <td width=122 nowrap colspan=3 style='width:91.8pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:solid windowtext 1.0pt;
  border-right:solid black 1.0pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'></td>
  <td width=260 colspan=5 valign=top style='width:195.15pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'></td>
  <td width=102 nowrap colspan=2 valign=top style='width:76.7pt;border-top:
  none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'></td>
  <td width=72 valign=top style='width:53.9pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'></td>
  <td width=169 nowrap colspan=2 valign=top style='width:127.1pt;border-top:
  none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.2pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:4.2pt;border:none' width=0 height=6></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:24;height:14.95pt'>
  <td width=48 style='width:36.1pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.95pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>A.<o:p></o:p></span></b></p>
  </td>
  <td width=74 nowrap colspan=2 style='width:55.7pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.95pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Certified:<o:p></o:p></span></b></p>
  </td>
  <td width=260 colspan=5 style='width:195.15pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.95pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Charges to appropriation/allotment are<o:p></o:p></span></p>
  </td>
  <td width=45 style='width:33.85pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-left-alt:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.95pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>B.<o:p></o:p></span></b></p>
  </td>
  <td width=299 nowrap colspan=4 style='width:223.9pt;border:none;border-right:
  solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.95pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><b><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Certified:</span></b><span style='font-family:
  "Times New Roman",serif;mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  EN-PH'> Allotment available and obligated<b><o:p></o:p></b></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:14.95pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:25;height:15.7pt'>
  <td width=48 nowrap style='width:36.1pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'></td>
  <td width=335 nowrap colspan=7 style='width:250.9pt;border:none;border-right:
  solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>necessary, lawful and under my direct
  supervision; and<o:p></o:p></span></p>
  </td>
  <td width=45 nowrap style='width:33.85pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.7pt'></td>
  <td width=299 nowrap colspan=4 style='width:223.9pt;border:none;border-right:
  solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>for the purpose/adjustment necessary as<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:15.7pt;border:none' width=0 height=21></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:26;height:15.7pt'>
  <td width=48 rowspan=2 style='width:36.1pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'></td>
  <td width=335 nowrap colspan=7 style='width:250.9pt;border:none;border-right:
  solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>supporting documents valid, proper and legal<o:p></o:p></span></p>
  </td>
  <td width=45 nowrap style='width:33.85pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.7pt'></td>
  <td width=129 nowrap colspan=2 style='width:96.75pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.7pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>indicated above<o:p></o:p></span></p>
  </td>
  <td width=82 nowrap style='width:61.55pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.7pt'></td>
  <td width=87 nowrap style='width:65.25pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.7pt;border:none' width=0 height=21></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:27;height:13.25pt'>
  <td width=34 nowrap style='width:25.75pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'></td>
  <td width=40 nowrap style='width:29.9pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'></td>
  <td width=48 nowrap style='width:36.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'></td>
  <td width=45 nowrap style='width:33.4pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-size:10.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=53 nowrap style='width:40.1pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'></td>
  <td width=18 nowrap style='width:13.35pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'></td>
  <td width=96 nowrap style='width:72.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <td width=45 nowrap style='width:33.85pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'></td>
  <td width=57 nowrap style='width:42.6pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'></td>
  <td width=72 nowrap style='width:54.15pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'></td>
  <td width=82 nowrap style='width:61.55pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:13.25pt'></td>
  <td width=87 nowrap style='width:65.25pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:28;height:14.55pt'>
  <td width=383 colspan=8 style='width:287.0pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:14.55pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Signature :<span style='mso-spacerun:yes'></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;___________________________________<o:p></o:p></span></p>
  </td>
  <td width=344 nowrap colspan=5 style='width:257.75pt;border:none;border-right:
  solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.55pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Signature<span style='mso-spacerun:yes'>�����
  </span>: ______________________________<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:14.55pt;border:none' width=0 height=19></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:29;height:10.35pt'>
  <td width=48 style='width:36.1pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:10.35pt'></td>
  <td width=34 style='width:25.75pt;padding:0cm 5.4pt 0cm 5.4pt;height:10.35pt'></td>
  <td width=40 style='width:29.9pt;padding:0cm 5.4pt 0cm 5.4pt;height:10.35pt'></td>
  <td width=48 style='width:36.1pt;padding:0cm 5.4pt 0cm 5.4pt;height:10.35pt'></td>
  <td width=45 style='width:33.4pt;padding:0cm 5.4pt 0cm 5.4pt;height:10.35pt'></td>
  <td width=53 style='width:40.1pt;padding:0cm 5.4pt 0cm 5.4pt;height:10.35pt'></td>
  <td width=18 style='width:13.35pt;padding:0cm 5.4pt 0cm 5.4pt;height:10.35pt'></td>
  <td width=96 style='width:72.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:10.35pt'></td>
  <td width=45 nowrap style='width:33.85pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:10.35pt'></td>
  <td width=57 nowrap style='width:42.6pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:10.35pt'></td>
  <td width=72 nowrap style='width:54.15pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:10.35pt'></td>
  <td width=82 nowrap style='width:61.55pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:10.35pt'></td>
  <td width=87 nowrap style='width:65.25pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:10.35pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:10.35pt;border:none' width=0 height=14></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:30;height:15.7pt'>
  <td width=383 colspan=8 style='width:287.0pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Printed Name :<span style='mso-spacerun:yes'></span><span
  style='mso-spacerun:yes'></span><b style='mso-bidi-font-weight:normal'>GEMMA
  D. DELA CRUZ</b><o:p></o:p></span></p>
  </td>
  <td width=344 nowrap colspan=5 style='width:257.75pt;border:none;border-right:
  solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Printed Name: <span
  style='mso-spacerun:yes'></span></span><b style='mso-bidi-font-weight:
  normal'><span style='font-size:10.5pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>JENIFER
  P. REYES</span></b><span style='font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:15.7pt;border:none' width=0 height=21></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:31;height:4.6pt'>
  <td width=48 style='width:36.1pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.6pt'></td>
  <td width=34 style='width:25.75pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.6pt'></td>
  <td width=40 style='width:29.9pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.6pt'></td>
  <td width=48 style='width:36.1pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.6pt'></td>
  <td width=45 style='width:33.4pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.6pt'></td>
  <td width=53 style='width:40.1pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.6pt'></td>
  <td width=18 style='width:13.35pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.6pt'></td>
  <td width=96 style='width:72.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.6pt'></td>
  <td width=45 nowrap style='width:33.85pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.6pt'></td>
  <td width=57 nowrap style='width:42.6pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.6pt'></td>
  <td width=72 nowrap style='width:54.15pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.6pt'></td>
  <td width=82 nowrap style='width:61.55pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:4.6pt'></td>
  <td width=87 nowrap style='width:65.25pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:4.6pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:4.6pt;border:none' width=0 height=6></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:32;height:13.25pt'>
  <td width=383 colspan=8 style='width:287.0pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Position<span style='mso-spacerun:yes'></span><span
  style='mso-spacerun:yes'></span>: <span
  style='mso-spacerun:yes'></span><u>OIC - Chief, Protective Services Division</u><o:p></o:p></span></p>
  </td>
  <td width=344 nowrap colspan=5 style='width:257.75pt;border:none;border-right:
  solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Position<span style='mso-spacerun:yes'>�������
  </span>:<span style='mso-spacerun:yes'></span><span
  style='mso-spacerun:yes'></span><span style='mso-spacerun:yes'></span><u>Administrative
  Officer IV</u><o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:33;height:34.0pt'>
  <td width=48 style='width:36.1pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:34.0pt'></td>
  <td width=335 colspan=7 style='width:250.9pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:34.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'></span>Head, Requesting Office/Authorized
  Representative<o:p></o:p></span></p>
  </td>
  <td width=45 nowrap style='width:33.85pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:34.0pt'></td>
  <td width=299 nowrap colspan=4 style='width:223.9pt;border:none;border-right:
  solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:34.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Head, Budget
  Division/Unit/Authorized Representative<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:34.0pt;border:none' width=0 height=45></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:34;height:13.25pt'>
  <td width=383 colspan=8 style='width:287.0pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Date : _______________________________<o:p></o:p></span></p>
  </td>
  <td width=344 nowrap colspan=5 style='width:257.75pt;border:none;border-right:
  solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:
  around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-811.55pt;mso-height-rule:exactly'><span
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Date<span style='mso-spacerun:yes'>������������
  </span>: ______________________________<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:35;height:15.45pt'>
  <td width=48 style='width:36.1pt;border-top:none;border-left:solid windowtext 1.0pt;
  border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-left-alt:
  solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:15.45pt'></td>
  <td width=34 style='width:25.75pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=40 style='width:29.9pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=48 style='width:36.1pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=45 style='width:33.4pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=53 style='width:40.1pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=18 style='width:13.35pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=96 style='width:72.1pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=45 style='width:33.85pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=57 style='width:42.6pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=72 style='width:54.15pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=82 style='width:61.55pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:15.45pt'></td>
  <td width=87 style='width:65.25pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.45pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.45pt;border:none' width=0 height=21></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:36;height:3.85pt'>
  <td width=48 nowrap style='width:36.1pt;border-top:none;border-left:solid windowtext 1.0pt;
  border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-top-alt:
  solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:
  solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:3.85pt'></td>
  <td width=34 nowrap style='width:25.75pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=40 nowrap style='width:29.9pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=48 nowrap style='width:36.1pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=45 nowrap style='width:33.4pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=53 nowrap style='width:40.1pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=18 nowrap style='width:13.35pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=96 nowrap style='width:72.1pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=45 nowrap style='width:33.85pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=57 nowrap style='width:42.6pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=72 nowrap style='width:54.15pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=82 nowrap style='width:61.55pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:3.85pt'></td>
  <td width=87 nowrap style='width:65.25pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:3.85pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:3.85pt;border:none' width=0 height=5></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:37;height:15.7pt'>
  <td width=48 nowrap style='width:36.1pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>C.<o:p></o:p></span></b></p>
  </td>
  <td width=678 nowrap colspan=12 style='width:508.65pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:15.7pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>STATUS OF OBLIGATION<o:p></o:p></span></b></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:15.7pt;border:none' width=0 height=21></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:38;height:14.15pt'>
  <td width=287 nowrap colspan=7 style='width:214.9pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:solid windowtext 1.0pt;
  border-right:solid black 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;height:14.15pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Reference<o:p></o:p></span></b></p>
  </td>
  <td width=440 nowrap colspan=6 style='width:329.85pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.15pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><b><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Amount<o:p></o:p></span></b></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:14.15pt;border:none' width=0 height=19></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:39;height:17.3pt'>
  <td width=48 nowrap rowspan=3 style='width:36.1pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-bottom-alt:solid black 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:17.3pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Date<o:p></o:p></span></p>
  </td>
  <td width=122 nowrap colspan=3 rowspan=3 style='width:91.8pt;border:none;
  border-bottom:solid black 1.0pt;mso-border-left-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.3pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Particulars<o:p></o:p></span></p>
  </td>
  <td width=116 colspan=3 rowspan=3 style='width:86.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:solid black 1.0pt;
  border-right:solid black 1.0pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid black 1.0pt;mso-border-right-alt:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.3pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>ORS/JEV/Check/<span
  style='mso-spacerun:yes'></span>ADA/TRA No.<o:p></o:p></span></p>
  </td>
  <td width=96 nowrap rowspan=2 style='width:72.1pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-left-alt:solid windowtext 1.0pt;mso-border-left-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:17.3pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Obligation<o:p></o:p></span></p>
  </td>
  <td width=102 nowrap colspan=2 rowspan=2 style='width:76.45pt;border:none;
  border-right:solid black 1.0pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.3pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Payable<o:p></o:p></span></p>
  </td>
  <td width=72 nowrap rowspan=2 style='width:54.15pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
  solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:17.3pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Payment<o:p></o:p></span></p>
  </td>
  <td width=169 nowrap colspan=2 style='width:126.85pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:17.3pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Balance<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:17.3pt;border:none' width=0 height=23></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:40;height:34.0pt'>
  <td width=82 nowrap style='width:61.55pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:34.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Not Yet Due<o:p></o:p></span></p>
  </td>
  <td width=87 style='width:65.25pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:34.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Due and Demandable<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:34.0pt;border:none' width=0 height=45></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:41;height:13.25pt'>
  <td width=96 nowrap style='width:72.1pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-top-alt:solid windowtext 1.0pt;mso-border-bottom-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>(a)<o:p></o:p></span></p>
  </td>
  <td width=102 nowrap colspan=2 style='width:76.45pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext 1.0pt;
  mso-border-right-alt:solid black .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:
  13.25pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>(b)<o:p></o:p></span></p>
  </td>
  <td width=72 nowrap style='width:54.15pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-top-alt:solid windowtext 1.0pt;mso-border-bottom-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>(c)<o:p></o:p></span></p>
  </td>
  <td width=82 nowrap style='width:61.55pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-top-alt:solid windowtext 1.0pt;mso-border-bottom-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>(a-b)<o:p></o:p></span></p>
  </td>
  <td width=87 style='width:65.25pt;border:solid windowtext 1.0pt;border-left:
  none;padding:0cm 5.4pt 0cm 5.4pt;height:13.25pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>(b-c)<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:13.25pt;border:none' width=0 height=18></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:42;height:14.15pt'>
  <td width=48 nowrap rowspan=4 style='width:36.1pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-left-alt:solid windowtext 1.0pt;mso-border-bottom-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0cm 5.4pt 0cm 5.4pt;height:14.15pt'></td>
  <td width=122 nowrap colspan=3 rowspan=4 style='width:91.8pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:14.15pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:
  "Times New Roman",serif;mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  EN-PH'>Reimbursement of Travel Expenses for the month of April 2021<o:p></o:p></span></p>
  </td>
  <td width=116 nowrap colspan=3 rowspan=4 style='width:86.95pt;border-top:
  none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.15pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><!--[if supportFields]><span style='font-size:10.0pt;mso-bidi-font-size:
  11.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'><span style='mso-element:field-begin'></span><span
  style='mso-spacerun:yes'>�</span>MERGEFIELD &quot;ORS_No&quot; </span><![endif]--><!--[if supportFields]><span
  style='font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-element:field-end'></span></span><![endif]--><span
  style='font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'>�</span><o:p></o:p></span></p>
  </td>
  <td width=96 nowrap rowspan=4 style='width:72.1pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:14.15pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>&#8369; 44,100.00</span><span
  style='font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><o:p></o:p></span></p>
  </td>
  <td width=102 nowrap colspan=2 rowspan=4 style='width:76.45pt;border-top:
  none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:14.15pt'>
  <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal;mso-element:frame;mso-element-frame-hspace:
  9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;
  mso-element-anchor-horizontal:margin;mso-element-top:-811.55pt;mso-height-rule:
  exactly'><span style='font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>&#8369; 44,100.00</span><span
  style='font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><o:p></o:p></span></p>
  </td>
  <td width=72 nowrap style='width:54.15pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.15pt'></td>
  <td width=82 nowrap style='width:61.55pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.15pt'></td>
  <td width=87 nowrap style='width:65.25pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:14.15pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:14.15pt;border:none' width=0 height=19></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:43;height:29.25pt'>
  <td width=72 nowrap style='width:54.15pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:29.25pt'></td>
  <td width=82 nowrap style='width:61.55pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:29.25pt'></td>
  <td width=87 nowrap style='width:65.25pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:29.25pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:29.25pt;border:none' width=0 height=39></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:44;height:14.15pt'>
  <td width=72 nowrap style='width:54.15pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.15pt'></td>
  <td width=82 nowrap style='width:61.55pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:14.15pt'></td>
  <td width=87 nowrap style='width:65.25pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:14.15pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:14.15pt;border:none' width=0 height=19></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:45;mso-yfti-lastrow:yes;height:114.4pt'>
  <td width=72 nowrap style='width:54.15pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:114.4pt'></td>
  <td width=82 nowrap style='width:61.55pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:114.4pt'></td>
  <td width=87 nowrap style='width:65.25pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:114.4pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:114.4pt;border:none' width=0 height=153></td>
  <![endif]>
 </tr>
</table>

<p class=MsoNormal><span style='font-family:"Times New Roman",serif'><o:p>&nbsp;</o:p></span></p>

</div>

</body>

</html>
