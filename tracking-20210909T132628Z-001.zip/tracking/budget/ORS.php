<?php
    // Connect to the database
    require_once "include/connection.php";

    session_start();

    if (!isset($_SESSION['username'])) {
        $_SESSION['msg'] = "You must log in first";
        header('location: login.php');
    }

    if (isset($_GET['logout'])) {
        session_destroy();
        unset($_SESSION['username']);
        header("location: login.php");
    }
    
    // Get contact details
    if (isset($_GET["id"])) {
        $id = preg_replace('/\D/', '', $_GET["id"]); //Accept numbers only
    } else {
        header("Location: index.php?p=update&err=no_id");
    }
    
    if ($stmt = $con->prepare("SELECT `user_Name`, `payee`, `particulars`, `programs`, `mfo`, `uacs`, `amount`, `ors`, `status` FROM `tbldocument` WHERE `id`=? LIMIT 1")) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($uname, $payee, $particulars, $programs, $mfo, $uacs, $amount, $ors, $status);
        $stmt->fetch();
        $stmt->free_result();
        $stmt->close();
    } else {
        die('prepare() failed: ' . htmlspecialchars($con->error));
    }
    
?>
<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 15">
<meta name=Originator content="Microsoft Word 15">
<link rel=File-List href="ORS_files/filelist.xml">
<link rel=Edit-Time-Data href="ORS_files/editdata.mso">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>Jassie Anne C. Tan</o:Author>
  <o:Template>Normal</o:Template>
  <o:LastAuthor>Akin Ramos</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>115</o:TotalTime>
  <o:LastPrinted>2021-04-21T06:34:00Z</o:LastPrinted>
  <o:Created>2021-07-07T14:59:00Z</o:Created>
  <o:LastSaved>2021-07-07T14:59:00Z</o:LastSaved>
  <o:Pages>1</o:Pages>
  <o:Words>274</o:Words>
  <o:Characters>1566</o:Characters>
  <o:Lines>13</o:Lines>
  <o:Paragraphs>3</o:Paragraphs>
  <o:CharactersWithSpaces>1837</o:CharactersWithSpaces>
  <o:Version>16.00</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:RelyOnVML/>
  <o:AllowPNG/>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<link rel=dataStoreItem href="ORS_files/item0007.xml"
target="ORS_files/props008.xml">
<link rel=themeData href="ORS_files/themedata.thmx">
<link rel=colorSchemeMapping href="ORS_files/colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:View>Print</w:View>
  <w:SpellingState>Clean</w:SpellingState>
  <w:GrammarState>Clean</w:GrammarState>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>EN-PH</w:LidThemeOther>
  <w:LidThemeAsian>JA</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:UseWord2010TableStyleRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:EnableOpenTypeKerning/>
   <w:DontFlipMirrorIndents/>
   <w:OverrideTableStyleHps/>
  </w:Compatibility>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="&#45;-"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/
   >
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="false"
  DefSemiHidden="false" DefQFormat="false" DefPriority="99"
  LatentStyleCount="376">
  <w:LsdException Locked="false" Priority="0" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index 9"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" Name="toc 9"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footnote text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="header"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footer"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="index heading"/>
  <w:LsdException Locked="false" Priority="35" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="table of figures"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="envelope address"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="envelope return"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="footnote reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="line number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="page number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="endnote reference"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="endnote text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="table of authorities"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="macro"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="toa heading"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Bullet 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Number 5"/>
  <w:LsdException Locked="false" Priority="10" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Closing"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Signature"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="true"
   UnhideWhenUsed="true" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="List Continue 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Message Header"/>
  <w:LsdException Locked="false" Priority="11" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Salutation"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Date"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text First Indent"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text First Indent 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Note Heading"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Body Text Indent 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Block Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Hyperlink"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="FollowedHyperlink"/>
  <w:LsdException Locked="false" Priority="22" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Document Map"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Plain Text"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="E-mail Signature"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Top of Form"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Bottom of Form"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Normal (Web)"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Acronym"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Address"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Cite"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Code"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Definition"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Keyboard"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Preformatted"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Sample"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Typewriter"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="HTML Variable"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="annotation subject"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="No List"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Outline List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Simple 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Classic 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Colorful 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Columns 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Grid 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table List 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table 3D effects 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Contemporary"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Elegant"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Professional"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Subtle 2"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Web 1"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Balloon Text"/>
  <w:LsdException Locked="false" Priority="39" Name="Table Grid"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Table Theme"/>
  <w:LsdException Locked="false" SemiHidden="true" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" SemiHidden="true" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" QFormat="true"
   Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" QFormat="true"
   Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" QFormat="true"
   Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" QFormat="true"
   Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" QFormat="true"
   Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" QFormat="true"
   Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" SemiHidden="true"
   UnhideWhenUsed="true" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="TOC Heading"/>
  <w:LsdException Locked="false" Priority="41" Name="Plain Table 1"/>
  <w:LsdException Locked="false" Priority="42" Name="Plain Table 2"/>
  <w:LsdException Locked="false" Priority="43" Name="Plain Table 3"/>
  <w:LsdException Locked="false" Priority="44" Name="Plain Table 4"/>
  <w:LsdException Locked="false" Priority="45" Name="Plain Table 5"/>
  <w:LsdException Locked="false" Priority="40" Name="Grid Table Light"/>
  <w:LsdException Locked="false" Priority="46" Name="Grid Table 1 Light"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark"/>
  <w:LsdException Locked="false" Priority="51" Name="Grid Table 6 Colorful"/>
  <w:LsdException Locked="false" Priority="52" Name="Grid Table 7 Colorful"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 1"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 1"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 1"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 2"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 2"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 2"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 3"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 3"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 3"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 4"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 4"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 4"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 5"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 5"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 5"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="46"
   Name="Grid Table 1 Light Accent 6"/>
  <w:LsdException Locked="false" Priority="47" Name="Grid Table 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="48" Name="Grid Table 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="49" Name="Grid Table 4 Accent 6"/>
  <w:LsdException Locked="false" Priority="50" Name="Grid Table 5 Dark Accent 6"/>
  <w:LsdException Locked="false" Priority="51"
   Name="Grid Table 6 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="52"
   Name="Grid Table 7 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="46" Name="List Table 1 Light"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark"/>
  <w:LsdException Locked="false" Priority="51" Name="List Table 6 Colorful"/>
  <w:LsdException Locked="false" Priority="52" Name="List Table 7 Colorful"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 1"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 1"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 1"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 1"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 2"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 2"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 2"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 2"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 3"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 3"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 3"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 3"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 4"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 4"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 4"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 4"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 5"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 5"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 5"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 5"/>
  <w:LsdException Locked="false" Priority="46"
   Name="List Table 1 Light Accent 6"/>
  <w:LsdException Locked="false" Priority="47" Name="List Table 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="48" Name="List Table 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="49" Name="List Table 4 Accent 6"/>
  <w:LsdException Locked="false" Priority="50" Name="List Table 5 Dark Accent 6"/>
  <w:LsdException Locked="false" Priority="51"
   Name="List Table 6 Colorful Accent 6"/>
  <w:LsdException Locked="false" Priority="52"
   Name="List Table 7 Colorful Accent 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Mention"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Smart Hyperlink"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Hashtag"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Unresolved Mention"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   Name="Smart Link"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:3 0 0 0 1 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-469750017 -1073732485 9 0 511 0;}
@font-face
	{font-family:"Segoe UI";
	panose-1:2 11 5 2 4 2 4 2 2 3;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-469750017 -1073683329 9 0 511 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin-top:0in;
	margin-right:0in;
	margin-bottom:8.0pt;
	margin-left:0in;
	line-height:107%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:EN-PH;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Balloon Text Char";
	margin:0in;
	mso-pagination:widow-orphan;
	font-size:9.0pt;
	font-family:"Segoe UI",sans-serif;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-ansi-language:EN-PH;}
span.BalloonTextChar
	{mso-style-name:"Balloon Text Char";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Balloon Text";
	mso-ansi-font-size:9.0pt;
	mso-bidi-font-size:9.0pt;
	font-family:"Segoe UI",sans-serif;
	mso-ascii-font-family:"Segoe UI";
	mso-hansi-font-family:"Segoe UI";
	mso-bidi-font-family:"Segoe UI";}
span.SpellE
	{mso-style-name:"";
	mso-spl-e:yes;}
span.GramE
	{mso-style-name:"";
	mso-gram-e:yes;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:EN-PH;}
.MsoPapDefault
	{mso-style-type:export-only;
	margin-bottom:8.0pt;
	line-height:107%;}
@page WordSection1
	{size:8.5in 14.0in;
	margin:0in .5in 0in .5in;
	mso-header-margin:35.3pt;
	mso-footer-margin:35.3pt;
	mso-paper-source:0;}
div.WordSection1
	{page:WordSection1;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin-top:0in;
	mso-para-margin-right:0in;
	mso-para-margin-bottom:8.0pt;
	mso-para-margin-left:0in;
	line-height:107%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:EN-PH;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1027"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US style='tab-interval:.5in;word-wrap:break-word'>

<div class=WordSection1 align="center">

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 align=center
 width=741 style='width:555.5pt;border-collapse:collapse;mso-yfti-tbllook:1184;
 mso-table-lspace:9.0pt;margin-left:6.75pt;mso-table-rspace:9.0pt;margin-right:
 6.75pt;mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:margin;
 mso-table-left:left;mso-table-top:-2.05pt;mso-padding-alt:0in 5.4pt 0in 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:23.2pt'>
  <td width=49 nowrap valign=bottom style='width:36.6pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=35 nowrap valign=bottom style='width:26.4pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=41 nowrap valign=bottom style='width:30.85pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=49 nowrap valign=bottom style='width:36.6pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=46 nowrap valign=bottom style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=55 nowrap valign=bottom style='width:41.2pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=19 nowrap valign=bottom style='width:13.95pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=98 nowrap valign=bottom style='width:73.2pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=46 nowrap valign=bottom style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=58 nowrap valign=bottom style='width:43.4pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=73 nowrap valign=bottom style='width:54.75pt;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'></td>
  <td width=173 nowrap colspan=2 style='width:1.8in;padding:0in 5.4pt 0in 5.4pt;
  height:23.2pt'>
  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><i><span lang=EN-PH
  style='font-size:16.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'>Appendix 11<o:p></o:p></span></i></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:23.2pt;border:none' width=0 height=31></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:1;height:10.25pt'>
  <td width=49 nowrap valign=bottom style='width:36.6pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=35 nowrap valign=bottom style='width:26.4pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=41 nowrap valign=bottom style='width:30.85pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=49 nowrap valign=bottom style='width:36.6pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=46 nowrap valign=bottom style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=55 nowrap valign=bottom style='width:41.2pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=19 nowrap valign=bottom style='width:13.95pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=98 nowrap valign=bottom style='width:73.2pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=46 nowrap valign=bottom style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=58 nowrap valign=bottom style='width:43.4pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=73 nowrap valign=bottom style='width:54.75pt;padding:0in 5.4pt 0in 5.4pt;
  height:10.25pt'></td>
  <td width=173 nowrap colspan=2 valign=bottom style='width:1.8in;border:none;
  border-bottom:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:10.25pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>&nbsp;<o:p></o:p></span></b></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:10.25pt;border:none' width=0 height=14></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:2;height:26.35pt'>
  <td width=495 colspan=10 style='width:371.15pt;border-top:solid windowtext 1.0pt;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:26.35pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><v:shapetype id="_x0000_t75"
   coordsize="21600,21600" o:spt="75" o:preferrelative="t" path="m@4@5l@4@11@9@11@9@5xe"
   filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="Picture_x0020_1" o:spid="_x0000_s1026" type="#_x0000_t75"
   style='position:absolute;left:0;text-align:left;margin-left:-.1pt;
   margin-top:6.5pt;width:54.75pt;height:47.45pt;z-index:-251658240;
   visibility:visible;mso-wrap-style:square;mso-width-percent:0;
   mso-height-percent:0;mso-wrap-distance-left:9pt;mso-wrap-distance-top:0;
   mso-wrap-distance-right:9pt;mso-wrap-distance-bottom:0;
   mso-position-horizontal:absolute;mso-position-horizontal-relative:text;
   mso-position-vertical:absolute;mso-position-vertical-relative:text;
   mso-width-percent:0;mso-height-percent:0;mso-width-relative:page;
   mso-height-relative:page'>
   <v:imagedata src="ORS_files/image001.jpg" o:title="1208-dswd"/>
  </v:shape><b><span lang=EN-PH style='font-size:9.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'></span><o:p></o:p></span></b></p>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-size:18.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'></span>OBLIGATION REQUEST AND STATUS<o:p></o:p></span></b></p>
  </td>
  <td width=246 colspan=3 valign=bottom style='width:184.35pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:26.35pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Serial <span
  class=GramE>No. :</span><u><?php echo $ors; ?></u><o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:26.35pt;border:none' width=0 height=35></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:3;height:27.6pt'>
  <td width=495 colspan=10 valign=bottom style='width:371.15pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:27.6pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'></span></span><b
  style='mso-bidi-font-weight:normal'><span lang=EN-PH style='font-size:12pt;
  font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>DEPARTMENT OF SOCIAL WELFARE AND DEVELOPMENT<o:p></o:p></span></b></p>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:12.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'><span
  style='mso-spacerun:yes'></span>Field Office XI<o:p></o:p></span></p>
  </td>
  <td width=246 colspan=3 style='width:184.35pt;border:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:27.6pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span class=GramE><span lang=EN-PH style='font-size:13.0pt;font-family:
  "Times New Roman",serif;mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  EN-PH'>Date :</span></span><span lang=EN-PH style='font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'> ________________________<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:27.6pt;border:none' width=0 height=37></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:4;height:4.65pt'>
  <td width=495 colspan=10 valign=top style='width:371.15pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.65pt'><a name="RANGE!A1:M44"></a></td>
  <td width=246 colspan=3 valign=top style='width:184.35pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.65pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Fund <span
  class=GramE>Cluster :</span> <o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:4.65pt;border:none' width=0 height=6></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:5;height:29.2pt'>
  <td width=125 colspan=3 style='width:93.95pt;border-top:solid windowtext 1.0pt;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-right-alt:solid black .5pt;padding:0in 5.4pt 0in 5.4pt;height:
  29.2pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Payee<o:p></o:p></span></p>
  </td>
  <td width=615 colspan=10 style='width:461.55pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:29.2pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><b><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><?php echo $payee; ?><o:p></o:p></span></b></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:29.2pt;border:none' width=0 height=39></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:6;height:23.9pt'>
  <td width=125 colspan=3 style='width:93.95pt;border-top:solid windowtext 1.0pt;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-right-alt:solid black .5pt;padding:0in 5.4pt 0in 5.4pt;height:
  23.9pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Office<o:p></o:p></span></p>
  </td>
  <td width=615 colspan=10 style='width:461.55pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-right-alt:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:23.9pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>TBD<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:23.9pt;border:none' width=0 height=32></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:7;height:27.65pt'>
  <td width=125 colspan=3 style='width:93.95pt;border-top:solid windowtext 1.0pt;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-right-alt:solid black .5pt;padding:0in 5.4pt 0in 5.4pt;height:
  27.65pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Address<o:p></o:p></span></p>
  </td>
  <td width=615 colspan=10 style='width:461.55pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-right-alt:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:27.65pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>TBD<o:p></o:p></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:27.65pt;border:none' width=0 height=37></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:8;height:29.55pt'>
  <td width=125 colspan=3 rowspan=2 style='width:93.95pt;border-top:windowtext;
  border-left:windowtext;border-bottom:black;border-right:black;border-style:
  solid;border-width:1.0pt;mso-border-top-alt:windowtext 1.0pt;mso-border-left-alt:
  windowtext 1.0pt;mso-border-bottom-alt:black 1.0pt;mso-border-right-alt:black .5pt;
  mso-border-style-alt:solid;padding:0in 5.4pt 0in 5.4pt;height:29.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Responsibility Center<o:p></o:p></span></p>
  </td>
  <td width=266 colspan=5 rowspan=2 style='width:199.4pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black 1.0pt;
  mso-border-right-alt:black .5pt;mso-border-style-alt:solid;padding:0in 5.4pt 0in 5.4pt;
  height:29.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Particulars<o:p></o:p></span></p>
  </td>
  <td width=104 colspan=2 rowspan=2 style='width:77.75pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black 1.0pt;
  mso-border-right-alt:black .5pt;mso-border-style-alt:solid;padding:0in 5.4pt 0in 5.4pt;
  height:29.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  color:black;mso-fareast-language:EN-PH'>MFO/PAP<o:p></o:p></span></p>
  </td>
  <td width=73 rowspan=2 style='width:54.75pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black 1.0pt;
  mso-border-right-alt:windowtext .5pt;mso-border-style-alt:solid;padding:0in 5.4pt 0in 5.4pt;
  height:29.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  color:black;mso-fareast-language:EN-PH'>UACS Object Code<o:p></o:p></span></p>
  </td>
  <td width=173 colspan=2 rowspan=2 style='width:1.8in;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:29.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Amount<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:29.55pt;border:none' width=0 height=39></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:9;height:29.55pt'>
  <![if !supportMisalignedRows]>
  <td style='height:29.55pt;border:none' width=0 height=39></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:10;height:15.05pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=266 nowrap colspan=5 rowspan=12 valign=top style='width:199.4pt;
  border:none;border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><?php echo $particulars; ?><o:p></o:p></span></p>
  </td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:11;height:15.05pt'>
  <td width=125 nowrap colspan=3 valign=top style='font-size:13.0pt;width:93.95pt;border-top:
  none;border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'><?php echo $programs; ?></td>
  <td width=104 nowrap colspan=2 valign=top style='font-size:13.0pt;width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'><?php echo $mfo; ?></td>
  <td width=73 nowrap valign=top style='font-size:13.0pt;width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'><?php echo $uacs; ?></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>&#8369;<?php echo $amount; ?><o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:12;height:21.85pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:21.85pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:21.85pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:21.85pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:21.85pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:21.85pt;border:none' width=0 height=29></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:13;height:15.05pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:14;height:15.05pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:15;height:15.05pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:16;height:15.05pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:17;height:15.05pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:18;height:15.05pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:19;height:18.65pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:18.65pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:18.65pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:18.65pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:18.65pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:18.65pt;border:none' width=0 height=25></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:20;height:18.65pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:18.65pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:18.65pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:18.65pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:18.65pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:18.65pt;border:none' width=0 height=25></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:21;height:4.65pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.65pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.65pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:4.65pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:4.65pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:4.65pt;border:none' width=0 height=6></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:22;height:17.75pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.75pt'></td>
  <td width=266 nowrap colspan=5 style='width:199.4pt;border:none;border-right:
  solid black 1.0pt;mso-border-right-alt:solid black .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.75pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Total<o:p></o:p></span></p>
  </td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.75pt'></td>
  <td width=73 nowrap valign=top style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:17.75pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border:none;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:17.75pt'>
  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>&#8369;<?php echo $amount; ?></span></b><span lang=EN-PH
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'><o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:17.75pt;border:none' width=0 height=24></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:23;height:4.65pt'>
  <td width=125 nowrap colspan=3 style='width:93.95pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:solid windowtext 1.0pt;
  border-right:solid black 1.0pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.65pt'></td>
  <td width=266 colspan=5 valign=top style='width:199.4pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.65pt'></td>
  <td width=104 nowrap colspan=2 valign=top style='width:77.75pt;border-top:
  none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.65pt'></td>
  <td width=73 valign=top style='width:54.75pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.65pt'></td>
  <td width=173 nowrap colspan=2 valign=top style='width:1.8in;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.65pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:4.65pt;border:none' width=0 height=6></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:24;height:16.95pt'>
  <td width=49 style='width:36.6pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.95pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>A.<o:p></o:p></span></b></p>
  </td>
  <td width=76 nowrap colspan=2 style='width:57.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.95pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Certified:<o:p></o:p></span></b></p>
  </td>
  <td width=266 colspan=5 style='width:199.4pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.95pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Charges
  to appropriation/allotment are<o:p></o:p></span></p>
  </td>
  <td width=46 style='width:34.3pt;border:solid windowtext 1.0pt;border-top:
  none;mso-border-left-alt:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.95pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>B.<o:p></o:p></span></b></p>
  </td>
  <td width=304 nowrap colspan=4 style='width:227.8pt;border:none;border-right:
  solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:16.95pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><b><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Certified:</span></b><span
  lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'> Allotment available and obligated<b><o:p></o:p></b></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:16.95pt;border:none' width=0 height=23></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:25;height:17.75pt'>
  <td width=49 nowrap style='width:36.6pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.75pt'></td>
  <td width=342 nowrap colspan=7 style='width:256.7pt;border:none;border-right:
  solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:17.75pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>necessary,
  lawful and under my direct supervision; and<o:p></o:p></span></p>
  </td>
  <td width=46 nowrap style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.75pt'></td>
  <td width=304 nowrap colspan=4 style='width:227.8pt;border:none;border-right:
  solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:17.75pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt; font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>for the
  purpose/adjustment necessary as<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:17.75pt;border:none' width=0 height=24></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:26;height:17.75pt'>
  <td width=49 rowspan=2 style='width:36.6pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.75pt'></td>
  <td width=342 nowrap colspan=7 style='width:256.7pt;border:none;border-right:
  solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:17.75pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>supporting
  documents valid, proper and legal<o:p></o:p></span></p>
  </td>
  <td width=46 nowrap style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.75pt'></td>
  <td width=131 nowrap colspan=2 style='width:98.15pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.75pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>indicated
  above<o:p></o:p></span></p>
  </td>
  <td width=83 nowrap style='width:62.45pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.75pt'></td>
  <td width=89 nowrap style='width:67.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.75pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:17.75pt;border:none' width=0 height=24></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:27;height:15.05pt'>
  <td width=35 nowrap style='width:26.4pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'></td>
  <td width=41 nowrap style='width:30.85pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'></td>
  <td width=49 nowrap style='width:36.6pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'></td>
  <td width=46 nowrap style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:10.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:
  "Times New Roman";mso-fareast-language:EN-PH'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=55 nowrap style='width:41.2pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'></td>
  <td width=19 nowrap style='width:13.95pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'></td>
  <td width=98 nowrap style='width:73.2pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <td width=46 nowrap style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'></td>
  <td width=58 nowrap style='width:43.4pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'></td>
  <td width=73 nowrap style='width:54.75pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'></td>
  <td width=83 nowrap style='width:62.45pt;padding:0in 5.4pt 0in 5.4pt;
  height:15.05pt'></td>
  <td width=89 nowrap style='width:67.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:28;height:16.5pt'>
  <td width=391 colspan=8 style='width:293.35pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:16.5pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Signature<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span><span class=GramE><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span>:</span> <span
  style='mso-spacerun:yes'></span>___________________________________<o:p></o:p></span></p>
  </td>
  <td width=350 nowrap colspan=5 style='width:262.15pt;border:none;border-right:
  solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:16.5pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Signature<span
  style='mso-spacerun:yes'></span><span class=GramE><span
  style='mso-spacerun:yes'></span>:</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 ______________________________<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:16.5pt;border:none' width=0 height=22></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:29;height:11.75pt'>
  <td width=49 style='width:36.6pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:11.75pt'></td>
  <td width=35 style='width:26.4pt;padding:0in 5.4pt 0in 5.4pt;height:11.75pt'></td>
  <td width=41 style='width:30.85pt;padding:0in 5.4pt 0in 5.4pt;height:11.75pt'></td>
  <td width=49 style='width:36.6pt;padding:0in 5.4pt 0in 5.4pt;height:11.75pt'></td>
  <td width=46 style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;height:11.75pt'></td>
  <td width=55 style='width:41.2pt;padding:0in 5.4pt 0in 5.4pt;height:11.75pt'></td>
  <td width=19 style='width:13.95pt;padding:0in 5.4pt 0in 5.4pt;height:11.75pt'></td>
  <td width=98 style='width:73.2pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:11.75pt'></td>
  <td width=46 nowrap style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:11.75pt'></td>
  <td width=58 nowrap style='width:43.4pt;padding:0in 5.4pt 0in 5.4pt;
  height:11.75pt'></td>
  <td width=73 nowrap style='width:54.75pt;padding:0in 5.4pt 0in 5.4pt;
  height:11.75pt'></td>
  <td width=83 nowrap style='width:62.45pt;padding:0in 5.4pt 0in 5.4pt;
  height:11.75pt'></td>
  <td width=89 nowrap style='width:67.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:11.75pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:11.75pt;border:none' width=0 height=16></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:30;height:17.75pt'>
  <td width=391 colspan=8 style='width:293.35pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.75pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Printed
  <span class=GramE>Name :</span><span style='mso-spacerun:yes'></span><span
  style='mso-spacerun:yes'></span><span
  style='mso-spacerun:yes'></span><b style='font-size:13.0pt;mso-bidi-font-weight:normal'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  TBD</b><o:p></o:p></span></p>
  </td>
  <td width=350 nowrap colspan=5 style='width:262.15pt;border:none;border-right:
  solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:17.75pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Printed
  Name: <span style='mso-spacerun:yes'></span></span><b
  style='mso-bidi-font-weight:normal'><span lang=EN-PH style='font-size:13pt;
  font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;TBD</span></b><span lang=EN-PH
  style='font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'><o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:17.75pt;border:none' width=0 height=24></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:31;height:5.2pt'>
  <td width=49 style='width:36.6pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:5.2pt'></td>
  <td width=35 style='width:26.4pt;padding:0in 5.4pt 0in 5.4pt;height:5.2pt'></td>
  <td width=41 style='width:30.85pt;padding:0in 5.4pt 0in 5.4pt;height:5.2pt'></td>
  <td width=49 style='width:36.6pt;padding:0in 5.4pt 0in 5.4pt;height:5.2pt'></td>
  <td width=46 style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;height:5.2pt'></td>
  <td width=55 style='width:41.2pt;padding:0in 5.4pt 0in 5.4pt;height:5.2pt'></td>
  <td width=19 style='width:13.95pt;padding:0in 5.4pt 0in 5.4pt;height:5.2pt'></td>
  <td width=98 style='width:73.2pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:5.2pt'></td>
  <td width=46 nowrap style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:5.2pt'></td>
  <td width=58 nowrap style='width:43.4pt;padding:0in 5.4pt 0in 5.4pt;
  height:5.2pt'></td>
  <td width=73 nowrap style='width:54.75pt;padding:0in 5.4pt 0in 5.4pt;
  height:5.2pt'></td>
  <td width=83 nowrap style='width:62.45pt;padding:0in 5.4pt 0in 5.4pt;
  height:5.2pt'></td>
  <td width=89 nowrap style='width:67.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:5.2pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:5.2pt;border:none' width=0 height=7></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:32;height:15.05pt'>
  <td width=391 colspan=8 style='width:293.35pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Position<span
  style='mso-spacerun:yes'></span><span
  style='mso-spacerun:yes'></span><span class=GramE><span
  style='mso-spacerun:yes'></span>:</span> <span
  style='mso-spacerun:yes'></span><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><u>TBD</u><o:p></o:p></span></p>
  </td>
  <td width=350 nowrap colspan=5 style='width:262.15pt;border:none;border-right:
  solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Position<span
  style='mso-spacerun:yes'></span><span class=GramE><span
  style='mso-spacerun:yes'></span>:</span><span style='mso-spacerun:yes'>
  </span><span style='mso-spacerun:yes'></span><span
  style='mso-spacerun:yes'></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  TBD<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:33;height:38.5pt'>
  <td width=49 style='width:36.6pt;border:none;border-left:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:38.5pt'></td>
  <td width=342 colspan=7 style='width:256.7pt;border:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:38.5pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'><span style='mso-spacerun:yes'></span>Head,
  Requesting Office/Authorized Representative<o:p></o:p></span></p>
  </td>
  <td width=46 nowrap style='width:34.3pt;padding:0in 5.4pt 0in 5.4pt;
  height:38.5pt'></td>
  <td width=304 nowrap colspan=4 style='width:227.8pt;border:none;border-right:
  solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:38.5pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Head, Budget Division/Unit/Authorized Representative<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:38.5pt;border:none' width=0 height=51></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:34;height:15.05pt'>
  <td width=391 colspan=8 style='width:293.35pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:none;border-right:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Date<span
  style='mso-spacerun:yes'></span><span class=GramE><span
  style='mso-spacerun:yes'></span>:</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;__________________________<o:p></o:p></span></p>
  </td>
  <td width=350 nowrap colspan=5 style='width:262.15pt;border:none;border-right:
  solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal style='margin-bottom:0in;line-height:normal;mso-element:
  frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:
  paragraph;mso-element-anchor-horizontal:margin;mso-element-top:-2.05pt;
  mso-height-rule:exactly'><span lang=EN-PH style='font-size:13.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'>Date<span
  style='mso-spacerun:yes'></span><span class=GramE><span
  style='mso-spacerun:yes'></span>:</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;
  ______________________________<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:35;height:17.45pt'>
  <td width=49 style='width:36.6pt;border-top:none;border-left:solid windowtext 1.0pt;
  border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-left-alt:
  solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:17.45pt'></td>
  <td width=35 style='width:26.4pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=41 style='width:30.85pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=49 style='width:36.6pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=46 style='width:34.3pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=55 style='width:41.2pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=19 style='width:13.95pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=98 style='width:73.2pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=46 style='width:34.3pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=58 style='width:43.4pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=73 style='width:54.75pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=83 style='width:62.45pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:17.45pt'></td>
  <td width=89 style='width:67.1pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-bottom-alt:
  solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:17.45pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:17.45pt;border:none' width=0 height=23></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:36;height:4.3pt'>
  <td width=49 nowrap style='width:36.6pt;border-top:none;border-left:solid windowtext 1.0pt;
  border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-top-alt:
  solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:
  solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:4.3pt'></td>
  <td width=35 nowrap style='width:26.4pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=41 nowrap style='width:30.85pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=49 nowrap style='width:36.6pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=46 nowrap style='width:34.3pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=55 nowrap style='width:41.2pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=19 nowrap style='width:13.95pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=98 nowrap style='width:73.2pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=46 nowrap style='width:34.3pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=58 nowrap style='width:43.4pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=73 nowrap style='width:54.75pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=83 nowrap style='width:62.45pt;border:none;border-bottom:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:4.3pt'></td>
  <td width=89 nowrap style='width:67.1pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:4.3pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:4.3pt;border:none' width=0 height=6></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:37;height:17.75pt'>
  <td width=49 nowrap style='width:36.6pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.75pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>C.<o:p></o:p></span></b></p>
  </td>
  <td width=692 nowrap colspan=12 style='width:518.9pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.75pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>STATUS OF OBLIGATION<o:p></o:p></span></b></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:17.75pt;border:none' width=0 height=24></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:38;height:16.0pt'>
  <td width=293 nowrap colspan=7 style='width:220.1pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:solid windowtext 1.0pt;
  border-right:solid black 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:16.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Reference<o:p></o:p></span></b></p>
  </td>
  <td width=447 nowrap colspan=6 style='width:335.4pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><b><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Amount<o:p></o:p></span></b></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:16.0pt;border:none' width=0 height=21></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:39;height:19.55pt'>
  <td width=49 nowrap rowspan=3 style='width:36.6pt;border-top:none;border-left:
  solid windowtext 1.0pt;border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-bottom-alt:solid black 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:19.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Date<o:p></o:p></span></p>
  </td>
  <td width=125 nowrap colspan=3 rowspan=3 style='width:93.95pt;border:none;
  border-bottom:solid black 1.0pt;mso-border-left-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Particulars<o:p></o:p></span></p>
  </td>
  <td width=119 colspan=3 rowspan=3 style='width:89.5pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:solid black 1.0pt;
  border-right:solid black 1.0pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid black 1.0pt;mso-border-right-alt:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>ORS/JEV/Check/<br><span
  style='mso-spacerun:yes'></span>ADA/TRA No.<o:p></o:p></span></p>
  </td>
  <td width=98 nowrap rowspan=2 style='width:73.2pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-left-alt:solid windowtext 1.0pt;mso-border-left-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:19.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Obligation<o:p></o:p></span></p>
  </td>
  <td width=104 nowrap colspan=2 rowspan=2 style='width:77.75pt;border:none;
  border-right:solid black 1.0pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Payable<o:p></o:p></span></p>
  </td>
  <td width=73 nowrap rowspan=2 style='width:54.75pt;border:none;border-right:
  solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
  solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:19.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Payment<o:p></o:p></span></p>
  </td>
  <td width=173 nowrap colspan=2 style='width:1.8in;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.55pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Balance<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:19.55pt;border:none' width=0 height=26></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:40;height:38.5pt'>
  <td width=83 nowrap style='width:62.45pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:38.5pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Not Yet Due<o:p></o:p></span></p>
  </td>
  <td width=89 style='width:67.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:38.5pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>Due and Demandable<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:38.5pt;border:none' width=0 height=51></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:41;height:15.05pt'>
  <td width=98 nowrap style='width:73.2pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-top-alt:solid windowtext 1.0pt;mso-border-bottom-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>(a)<o:p></o:p></span></p>
  </td>
  <td width=104 nowrap colspan=2 style='width:77.75pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext 1.0pt;
  mso-border-right-alt:solid black .5pt;padding:0in 5.4pt 0in 5.4pt;height:
  15.05pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>(b)<o:p></o:p></span></p>
  </td>
  <td width=73 nowrap style='width:54.75pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-top-alt:solid windowtext 1.0pt;mso-border-bottom-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>(c)<o:p></o:p></span></p>
  </td>
  <td width=83 nowrap style='width:62.45pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-top-alt:solid windowtext 1.0pt;mso-border-bottom-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>(a-b)<o:p></o:p></span></p>
  </td>
  <td width=89 style='width:67.1pt;border:solid windowtext 1.0pt;border-left:
  none;padding:0in 5.4pt 0in 5.4pt;height:15.05pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>(b-c)<o:p></o:p></span></p>
  </td>
  <![if !supportMisalignedRows]>
  <td style='height:15.05pt;border:none' width=0 height=20></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:42;height:16.0pt'>
  <td width=49 nowrap rowspan=4 style='width:36.6pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-left-alt:solid windowtext 1.0pt;mso-border-bottom-alt:
  solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
  0in 5.4pt 0in 5.4pt;height:16.0pt'></td>
  <td width=125 nowrap colspan=3 rowspan=4 style='width:93.95pt;border-top:
  none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:16.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;mso-bidi-font-size:11.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><?php echo $particulars; ?><o:p></o:p></span></p>
  </td>
  <td width=119 nowrap colspan=3 rowspan=4 style='width:89.5pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><!--[if supportFields]><span
  lang=EN-PH style='font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:
  "Times New Roman",serif;mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  EN-PH'><span style='mso-element:field-begin'></span><span
  style='mso-spacerun:yes'>�</span>MERGEFIELD &quot;ORS_No&quot; </span><![endif]--><!--[if supportFields]><span
  lang=EN-PH style='font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:
  "Times New Roman",serif;mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  EN-PH'><span style='mso-element:field-end'></span></span><![endif]--><span
  lang=EN-PH style='font-size:13.0pt;mso-bidi-font-size:11.0pt;font-family:
  "Times New Roman",serif;mso-fareast-font-family:"Times New Roman";mso-fareast-language:
  EN-PH'><span style='mso-spacerun:yes'><?php echo $ors; ?></span><o:p></o:p></span></p>
  </td>
  <td width=98 nowrap rowspan=4 style='width:73.2pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:16.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>&#8369; <?php echo $amount; ?></span><span lang=EN-PH
  style='font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><o:p></o:p></span></p>
  </td>
  <td width=104 nowrap colspan=2 rowspan=4 style='width:77.75pt;border-top:
  none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:16.0pt'>
  <p class=MsoNormal align=center style='margin-bottom:0in;text-align:center;
  line-height:normal;mso-element:frame;mso-element-frame-hspace:9.0pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  margin;mso-element-top:-2.05pt;mso-height-rule:exactly'><span lang=EN-PH
  style='font-size:13.0pt;font-family:"Times New Roman",serif;mso-fareast-font-family:"Times New Roman";
  mso-fareast-language:EN-PH'>&#8369; <?php echo $amount; ?></span><span lang=EN-PH
  style='font-size:10.0pt;mso-bidi-font-size:11.0pt;font-family:"Times New Roman",serif;
  mso-fareast-font-family:"Times New Roman";mso-fareast-language:EN-PH'><o:p></o:p></span></p>
  </td>
  <td width=73 nowrap style='width:54.75pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.0pt'></td>
  <td width=83 nowrap style='width:62.45pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.0pt'></td>
  <td width=89 nowrap style='width:67.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:16.0pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:16.0pt;border:none' width=0 height=21></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:43;height:33.15pt'>
  <td width=73 nowrap style='width:54.75pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:33.15pt'></td>
  <td width=83 nowrap style='width:62.45pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:33.15pt'></td>
  <td width=89 nowrap style='width:67.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:33.15pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:33.15pt;border:none' width=0 height=44></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:44;height:16.0pt'>
  <td width=73 nowrap style='width:54.75pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.0pt'></td>
  <td width=83 nowrap style='width:62.45pt;border:none;border-right:solid windowtext 1.0pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt;
  height:16.0pt'></td>
  <td width=89 nowrap style='width:67.1pt;border:none;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:16.0pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:16.0pt;border:none' width=0 height=21></td>
  <![endif]>
 </tr>
 <tr style='mso-yfti-irow:45;mso-yfti-lastrow:yes;height:129.8pt'>
  <td width=73 nowrap style='width:54.75pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:129.8pt'></td>
  <td width=83 nowrap style='width:62.45pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0in 5.4pt 0in 5.4pt;height:129.8pt'></td>
  <td width=89 nowrap style='width:67.1pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0in 5.4pt 0in 5.4pt;height:129.8pt'></td>
  <![if !supportMisalignedRows]>
  <td style='height:129.8pt;border:none' width=0 height=173></td>
  <![endif]>
 </tr>
</table>

<p class=MsoNormal><a name="RANGE!A1:M46"></a><span lang=EN-PH
style='font-family:"Times New Roman",serif'><o:p>&nbsp;</o:p></span></p>

</div>

</body>

</html>
