<?php include('include/server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
	<title>Accounting | Register</title>
	<link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" type="image/png" href="logo/Finallogo.png"/>
</head>
<body class="bg-light">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header bg-white"><h3 class="text-center font-weight-light my-4">Register</h3></div>
                                    <p style="text-align: center;"><img src="logo/dswdlogo1.png" alt="dswdlogo" width="400" height="190"></p>
                                    <div class="card-body">
									<?php include('include/errors.php'); ?>
										<form method="post">
											<div class="form-floating mb-3">
												<input class="form-control" type="text" name="username" placeholder="Username" autocomplete="off" value="<?php echo $username; ?>">
													<label for="username">Username</label>
											</div>	
											
											<div class="form-floating mb-3">	
												<input class="form-control" type="email" name="email" placeholder="Email" autocomplete="off" value="<?php echo $email; ?>">
													<label for="email">Email</label>
											</div>	

											<div class="row mb-3">
												<div class="col-md-6">	
													<div class="form-floating mb-3 mb-md-0">
														<input class="form-control" type="password" name="password_1" placeholder="Password" autocomplete="off">
														<label for="password_1">Password</label>
													</div>
												</div>

												<div class="col-md-6">	
													<div class="form-floating mb-3 mb-md-0">
														<input class="form-control" type="password" name="password_2" placeholder="Confirm Password" autocomplete="off">
														<label for="password_2">Confirm Password</label>
													</div>
												</div>	
											</div>	

												<div class="mt-4 mb-0">
													<div class="d-grid">
														<button type="submit" class="button btn btn-primary btn-block" name="reg_user">Register</button>
													</div>
												</div>													
										</form>		
                                    </div>

                                    		<div class="card-footer bg-white text-center py-3">
                                        		<div class="small"><a href="login.php">Have an account? Go to login</a></div>
                                    		</div>

                                </div>
                            </div>
                        </div>
                    </div>
                </main>  
            </div>

            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-white mt-auto border-top">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Akin Lou M. Ramos 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>          
		</div>	
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
</body>
</html>

































