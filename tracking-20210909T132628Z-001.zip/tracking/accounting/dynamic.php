<?php
  include_once 'include/connection.php';

  if($_POST['tag']=='programList')
  {
    $query = "select * from tblprograms";

    $result = mysqli_query($con,$query);

    $arr =[];
    $i=0;

    while($row = mysqli_fetch_assoc($result))
    {
      $arr[$i] = $row;
      $i++;
    }

    echo json_encode($arr);
  }

  // Getting item list on the basis of program_id
  if($_POST['tag']=='mfoList')
  { 
    $program_id = $_POST['program_id'];

    $query = "select * from tblmfo where program_id ='".$program_id."'" ;

    $result = mysqli_query($con,$query);

    $arr =[];
    $i=0;

    while($row = mysqli_fetch_assoc($result))
    {
      $arr[$i] = $row;
      $i++;
    }

    echo json_encode($arr);
  }

   
?>