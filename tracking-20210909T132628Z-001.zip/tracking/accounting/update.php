<?php
    // Connect to the database
    require_once "include/connection.php";

    session_start();

    if (!isset($_SESSION['username'])) {
        $_SESSION['msg'] = "You must log in first";
        header('location: login.php');
    }

    if (isset($_GET['logout'])) {
        session_destroy();
        unset($_SESSION['username']);
        header("location: login.php");
    }
    
    // Get contact details
    if (isset($_GET["id"])) {
        $id = preg_replace('/\D/', '', $_GET["id"]); //Accept numbers only
    } else {
        header("Location: index.php?p=update&err=no_id");
    }

    // Update contact details
    if (isset($_POST["btnUpdate"])) {

        require_once "include/connection.php";

        $uname=$_SESSION['username'];
        $payee    = $con->real_escape_string($_POST["payee"]);
        $particulars    = $con->real_escape_string($_POST["particulars"]);
        $programs = $con->real_escape_string($_POST["programs"]);
        $mfo = $con->real_escape_string($_POST["mfo"]);
        $uacs = $con->real_escape_string($_POST["uacs"]);
        $amount  = $con->real_escape_string($_POST["amount"]);
        $ors  = $con->real_escape_string($_POST["ors"]);
        $status  = $con->real_escape_string($_POST["status"]);

        if ($stmt = $con->prepare("UPDATE `tbldocument` SET `user_Name`=?, `payee`=?, `particulars`=?, `programs`=?, `mfo`=?, `uacs`=?, `amount`=?,
         `ors`=?, `status`=? WHERE `id`=?")) {
            $stmt->bind_param("sssssssssi", $uname, $payee, $particulars, $programs, $mfo, $uacs, $amount, $ors, $status, $id);
            $stmt->execute();
            $stmt->close();
            $msg = '<div class="msg msg-update alert alert-success text-center">Obligation Request Updated successfully.</div>';
        } else {
            $msg = '<div class="msg">Prepare() failed: '.htmlspecialchars($con->error).'</div>';
        }
    }

    
    if ($stmt = $con->prepare("SELECT `user_Name`, `payee`, `particulars`, `programs`, `mfo`, `uacs`, `amount`, `ors`, `status` FROM `tbldocument` WHERE `id`=? LIMIT 1")) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($uname, $payee, $particulars, $programs, $mfo, $uacs, $amount, $ors, $status);
        $stmt->fetch();
        $stmt->free_result();
        $stmt->close();
    } else {
        die('prepare() failed: ' . htmlspecialchars($con->error));
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Accounting | Update Obligation Request</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" type="image/png" href="logo/Finallogo.png"/>
</head>
<body>
    
     <nav class="sb-topnav navbar navbar-expand navbar-dark shadow-sm p-3 bg-warning">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" style="font-weight: bold;" href="index.html">Start Bootstrap</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">

            <a href="pending.php">
                <button type="button" class="btn btn-dark  btn-sm position-relative"><i class="far fa-bell"></i>&nbsp;Pending 
                    <span class="position-absolute top-10 start-100 translate-middle badge rounded-pill bg-danger">
                            <?php
                                $st = 'Forward Accounting';                
                                $rt = mysqli_query($con, "SELECT * FROM tbldocument where status = '$st'");
                                $num1 = mysqli_num_rows($rt);
                            {?>
                        <?php echo htmlentities($num1); ?>
                    </span>
                </button>
            </a>    

                <div class="input-group">
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="login.php?logout='1'">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="index.html">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Obligation Request</div>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Obligation Request
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="create.php"><i class="fas fa-folder-plus"></i>&nbsp;Add Obligation</a>

                                    <a class="nav-link" href="in-process.php"><i class="fas fa-server"></i> &nbsp;In Process&nbsp;

                                        <?php
                                            
                                            $rt = mysqli_query($con, "SELECT * FROM tbldocument where status is NULL");
                                            $num1 = mysqli_num_rows($rt);
                                        {?>

                                        <span class="badge bg-danger"> <?php echo htmlentities($num1); ?></span>
                                    </a>

                                </nav>
                            </div>

                            <div class="sb-sidenav-menu-heading">Disbursement</div>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayoutsdisbursement" aria-expanded="false" aria-controls="collapseLayoutsdisbursement">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Disbursement
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>

                            <div class="collapse" id="collapseLayoutsdisbursement" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="approved.php"> <i class="fas fa-server"></i> &nbsp;In Process&nbsp;
                                        
                                        <?php

                                            $st = 'acceptedacctng';
                                            $rt = mysqli_query($con, "SELECT * FROM tbldocument where status = '$st'");
                                            $num1 = mysqli_num_rows($rt);
                                        {?>

                                        <span class="badge bg-danger"><?php echo htmlentities($num1); ?></span> 
                                    </a>

                                </nav>
                            </div>

                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Pages
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth">
                                        Authentication
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionPages">
                                        <nav class="sb-sidenav-menu-nested nav">
                                            <a class="nav-link" href="login.html">Login</a>
                                            <a class="nav-link" href="register.html">Register</a>
                                            <a class="nav-link" href="password.html">Forgot Password</a>
                                        </nav>
                                    </div>
                                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pagesCollapseError" aria-expanded="false" aria-controls="pagesCollapseError">
                                        Error
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionPages">
                                        <nav class="sb-sidenav-menu-nested nav">
                                            <a class="nav-link" href="401.html">401 Page</a>
                                            <a class="nav-link" href="404.html">404 Page</a>
                                            <a class="nav-link" href="500.html">500 Page</a>
                                        </nav>
                                    </div>
                                </nav>
                            </div>
                            <div class="sb-sidenav-menu-heading">Addons</div>
                            <a class="nav-link" href="charts.html">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                                Charts
                            </a>
                            <a class="nav-link" href="tables.html">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Tables
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer bg-dark">
                        <div class="small">Logged in as: </div>
                        <?php echo $_SESSION['username']; ?>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4">Update Obligation Request</h4>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active"></li>
                        </ol>
                        <div class="card mb-4">
                            <div class="card-body">
                                <p class="mb-0">
                                  
                                  <a href="in-process.php"><i class="fas fa-arrow-left fa-lg" style="margin-bottom: 12px;" ></i></a>

                                    <form action="<?=$_SERVER['PHP_SELF']."?id=".$id;?>" method="post" class="frmUpdate">

                                     <div class="row justify-content-center"></div>                
                                    <?php if(isset($msg)){ echo $msg; }?>
                                    <div class="row">
                                      <div class="col">
                                        <!-- Name input -->
                                        <div class="form-outline">
                                          <label class="form-label"  for="payee">Payee</label>
                                          <input class="form-control" type="text" name="payee" placeholder="Enter Payee" value="<?php echo $payee; ?>" >
                                        </div>
                                      </div>
                                    </div>
                                  
                                    <div class="dropdown-divider" id="divider"></div>

                                      <div class="col">
                                        <!-- Email input -->
                                        <div class="form-outline">
                                          <label class="form-label" for="particulars">Particulars</label>  
                                          <input class="form-control" type="text" name="particulars" placeholder="Enter Particulars" value="<?php echo $particulars; ?>" >
                                        </div>
                                      </div>
                                    
                                    <div class="dropdown-divider" id="divider"></div>

                                    <div class="row">
                                      <div class="col">
                                        <!-- Name input -->
                                        <div class="form-outline">
                                          <label class="form-label" for="form8Example3">Responsibility Center</label>  
                                            <input class="form-control" id="programs" name="programs" placeholder="Responsibility Center" value="<?php echo $programs; ?>"/>
                                        </div>
                                      </div>

                                      <div class="col">
                                        <!-- Name input -->
                                        <div class="form-outline">
                                          <label class="form-label" for="mfo">MFO/PAP</label>  
                                            <input class="form-control" id="mfo" name="mfo" placeholder="MFO/PAP" value="<?php echo $mfo; ?>" />
                                        </div>
                                      </div>

                                      <div class="col">
                                        <!-- Email input -->
                                        <div class="form-outline">
                                          <label class="form-label" for="uacs">UACS/OBJECT CODE</label>  
                                            <input class="form-control" id="uacs" name="uacs" placeholder="UACS/OBJECT CODE" value="<?php echo $uacs; ?>" > 
                                        </div>
                                      </div>
                                    </div>

                                   
                                    <div class="dropdown-divider" id="divider"></div>
                                    <div class="row">
                                      <div class="col">
                                        <!-- Name input -->
                                        <div class="form-outline">
                                            <label class="form-label" for="amount">Amount</label>
                                              <input class="form-control" type="text" min="0" name="amount" placeholder="Enter Amount" value="<?php echo $amount; ?>">
                                        </div>
                                      </div>

                                      <div class="col">
                                        <!-- Name input -->
                                        <div class="form-outline">
                                            <label class="form-label" for="ors">Enter ORS No.</label>
                                              <input class="form-control" type="text" name="ors" placeholder="Enter ORS No." value="<?php echo $ors; ?>" required>
                                        </div>
                                      </div>

                                      <div class="col">
                                        <!-- Name input -->
                                        <div class="form-outline">
                                            <label class="form-label" for="status">Status</label>
                                            <select class="form-select" id="status" type="text"  name="status" placeholder="Enter Status" value="<?php echo $status; ?>" required>
                                                    <option value="">-- Status --</option>
                                                    <option value="Forward Accounting">Forward to Accounting</option>
                                                    <option value="Closed">Closed</option>

                                            </select> 
                                        </div>
                                      </div>
                                    </div>

                                    <div class="dropdown-divider" id="divider"></div>

                                    <div class="mt-4 mb-0">
                                        <div class="btn-group">
                                            <button type="submit" class="button btn btn-primary btn-sm" name="btnUpdate">
                                            <i class="far fa-edit"></i> Update</button> 
                                        </div>

                                        <a href="PrintORS.php" class="btn btn-outline-dark btn-sm float-left" name="btnPrint">
                                            <i class="fas fa-print"></i> Print </a>
                                                    
                                    </div>

                                <div class="dropdown-divider" id="divider"></div>
                                                                    
                                </form>                                                        
                                </p>    
                            </div>
                        </div>


                </main>
                <footer class="py-4 bg-white mt-auto border-top">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Akin Lou M. Ramos 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>

</body>
</html>
<?php } ?>
<?php } ?>
<?php } ?>
 