
-- phpMyAdmin SQL Dump

-- version 5.0.2

-- https://www.phpmyadmin.net/

--

-- Host: 127.0.0.1

-- Generation Time: Apr 01, 2021 at 11:29 PM

-- Server version: 10.4.14-MariaDB

-- PHP Version: 7.4.10



SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

START TRANSACTION;

SET time_zone = "+00:00";





/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;

/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;

/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;

/*!40101 SET NAMES utf8mb4 */;



--

-- Database: `crud_search`

--



-- --------------------------------------------------------


-- Table Structure for table 'users'

CREATE TABLE `users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--

-- Table structure for table `tbldocument`

--



CREATE TABLE `tbldocument` (

  `id` int(11) NOT NULL,

  `user_Name` varchar(255) NOT NULL,

  `creationDate` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  `payee` varchar(255) NOT NULL,

  `particulars` varchar(255) NOT NULL,

  `programs` varchar(255) NOT NULL,

  `mfo` varchar(50) NOT NULL,

  `uacs` varchar(50) NOT NULL,

  `amount` varchar(50) NOT NULL,

  `ors` varchar(50) NOT NULL,

  `dv` varchar(50) NOT NULL,

  `tax` varchar(50) NOT NULL,  

  `status` varchar(50) DEFAULT NULL

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




-- Table for Programs

CREATE TABLE `tblprograms` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `programs` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



INSERT INTO `tblprograms` (`id`, `programs`) VALUES
(1,'Administration of Personnel Benefits'),
(2,'Assistance to Persons with Disability and Older Persons'),
(3,'Comprehensive Proj. for Street Children, Street Families & Ips - Esp. Badjaus'),
(4,'Disaster response and rehabilitation program'),
(5,'Enhancement Partnership Against Hunger and Poverty - National Program Management Office (EPAHP-NPMO)'),
(6,'Formulation and Development of Policies and Plans'),
(7,'General Administration Support Services'),
(8,'Implementation and Monitoring of PAMANA Program DSWD/LGU Led Livelihood'),
(9,'Implementation and Monitoring of Payapa at Masaganang Pamayanan Program - Peace and Development Fund'),
(10,'Implementation of RA No. 10868 or the Centenarians Act of 2016'),
(11,'Information and Communication Technology Service Management'),
(12,'Kapit-Bisig Laban sa Kahirapan-Comprehensive and Integrated Delivery of Social Services: Kapangyarihan at Kaunlaran sa Barangay (KALAHI-CIDSS-KKB)'),
(13,'Kapit-Bisig Laban sa Kahirapan-Comprehensive and Integrated Delivery of Social Services: Kapangyarihan at Kaunlaran sa Barangay (KALAHI-CIDSS-KKB)'),
(14,'Kapit-Bisig Laban sa Kahirapan-Comprehensive and Integrated Delivery of Social Services: National Community Driven Development Project'),
(15,'National Household Targeting System for Poverty Reduction (NHTS-PR)'),
(16,'National Resource Operation'),
(17,'Pantawid Pamilyang Pilipino Program (Implementation of Conditional Cash Transfer)'),
(18,'Poverty and Reintegration Progam for Trafficked Persons'),
(19,'Protective Services for Individuals and Families in Difficult Circumstances'),
(20,'Provision of Capability Training Program'),
(21,'Provision of technical/advisory assistance and other related support services'),
(22,'Quick Response Fund'),
(23,'Reducing Vulnerabilities of Children from hunger and malnutrition in ARMM or Bangsamoro Umpungan sa Nutrisyon (Bangun)'),
(24,'Services for residential and center-based clients'),
(25,'Services to Displaced Persons (Deportees)'),
(26,'Services to Distressed Overseas Filipinos'),
(27,'Social Marketing Services'),
(28,'Social Pension for Indigent Senior Citizens'),
(29,'Social Technology Development and Enhancement'),
(30,'Standards-setting, Licensing, accreditation and monitoring services'),
(31,'Supplementary Feeding Program'),
(32,'Sustainable Livelihood Program'),
(33,'Tax Reform Cash Transfer Project');





-- Table for MFO PAP
CREATE TABLE `tblmfo` (
  `id` int(11) not null AUTO_INCREMENT primary key,
  `mfo_name` varchar(255) not null,
  `program_id` varchar(255) not null

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `tblmfo` (`id`, `mfo_name`, `program_id`) VALUES
(1,'100000100002000',"1"),
(2,'320104100002000',"2"),
(3,'320104200001000',"3"),
(4,'330100100001000',"4"),
(5,'200000100005000',"5"),
(6,'200000100004000',"6"),
(7,'100000100001000',"7"),
(8,'330100200002000',"8"),
(9,'330100200001000',"9"),
(10,'320103100002000',"10"),
(11,'200000100001000',"11"),
(12,'310100200001000',"12"),
(13,'310100200002000',"13"),
(14,'310100300001000',"14"),
(15,'200000200001000',"15"),
(16,'330100100002000',"16"),
(17,'310100100001000',"17"),
(18,'320105100003000',"18"),
(19,'320104100001000',"19"),
(20,'350100100002000',"20"),
(21,'350100100001000',"21"),
(22,'330100100003000',"22"),
(23,'320104200002000',"23"),
(24,'320101100001000',"24"),
(25,'320105100002000',"25"),
(26,'320105100001000',"26"),
(27,'200000100002000',"27"),
(28,'320103100001000',"28"),
(29,'200000100003000',"29"),
(30,'340100100001000',"30"),
(31,'320102100001000',"31"),
(32,'310100100002000',"32"),
(33,'320104200003000',"33");




-- Table for UACS Object Code
CREATE TABLE `tbluacs` (
  `id` int(11) not null AUTO_INCREMENT primary key,
  `uacs` varchar(255) not null

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `tbluacs` (`id`, `uacs`) VALUES
(1,'50101010-01'),
(2,'50101020-02'),
(3,'50102010-01'),
(4,'50102020-00'),
(5,'50102030-01'),
(6,'50102040-01'),
(7,'50102060-04'),
(8,'50102080-01'),
(9,'50102120-01'),
(10,'50102130-01'),
(11,'50102130-02'),
(12,'50102140-01'),
(13,'50102150-01'),
(14,'50102990-12'),
(15,'50102990-14'),
(16,'50103010-00'),
(17,'50103020-01'),
(18,'50103030-01'),
(19,'50103040-01'),
(20,'50104030-01'),
(21,'50104990-10'),
(22,'50104990-99'),
(23,'50201010-00'),
(24,'50201020-00'),
(25,'50202010-00'),
(26,'50202020-00'),
(27,'50203010-00'),
(28,'50203020-00'),
(29,'50203050-00'),
(30,'50203070-00'),
(31,'50203080-00'),
(32,'50203090-00'),
(33,'50203990-00'),
(34,'50204010-00'),
(35,'50204020-00'),
(36,'50205010-00'),
(37,'50205020-01'),
(38,'50205020-02'),
(39,'50205030-00'),
(40,'50205040-00'),
(41,'50299010-00'),
(42,'50299020-00'),
(43,'50299050-00'),
(44,'50299050-01'),
(45,'50299050-03'),
(46,'50299050-04'),
(47,'50299030-00'),
(48,'50299040-00'),
(49,'50299070-00'),
(50,'50211010-00'),
(51,'50211030-00'),
(52,'50212000-00'),
(53,'50212020-00'),
(54,'50212030-00'),
(55,'50211990-00'),
(56,'50213040-00'),
(57,'50213050-00'),
(58,'50213070-00'),
(59,'50213050-00'),
(60,'50213050-00'),
(61,'50213060-00'),
(62,'50214990-00'),
(63,'50210030-00'),
(64,'50215020-00'),
(65,'50215030-00'),
(66,'50299990-00');


-- Table for Controller
CREATE TABLE `tblcontroller` (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `controller` varchar(255) not null

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblcontroller` (`id`, `controller`) VALUES
(1,'Grace'),
(2,'Chard'),
(3,'Lailanie'),
(4,'Darlene'),
(5,'Jassie'),
(6,'Marivic'),
(7,'Chona'),
(8,'Stella'),
(9,'Thwinnie'),
(10,'Emerson'),
(11,'Alyssa'),
(12,'Aravon'),
(13,'Anna'),
(14,'James Sy.'),
(15,'Genalyn'),
(16,'Marilyn'),
(17,'James Deriada');








--

-- Indexes for dumped tables

--



--

-- Indexes for table `contacts`

--

ALTER TABLE `tbldocument`

  ADD PRIMARY KEY (`id`);



--

-- AUTO_INCREMENT for dumped tables

--



--

-- AUTO_INCREMENT for table `contacts`

--

ALTER TABLE `tbldocument`

  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

COMMIT;



/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;

/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;